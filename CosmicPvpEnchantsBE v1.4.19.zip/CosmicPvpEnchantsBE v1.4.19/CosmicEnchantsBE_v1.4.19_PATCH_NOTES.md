# CosmicEnchantsBE — Patch notes

**From:** `v1.4.13` (previous release)  
**To:** `v1.4.19` (this release)  
**Date:** 2026-07-14  
**File:** `CosmicEnchantsBE_v1.4.19.mcaddon`

---

## Summary

Shop loot, prize chests, safer lightning, rolled book rates, and CosmicPvP-style combat for Rage / Bleed / Devour / Cleave (plus stronger sword, axe, bow, and tool behavior). All earlier project rules (scrolls, Blessed, Drunk, max 9, etc.) are kept.

---

## Added

### Prize chest (XP shop)
- **Cosmic Prize Chest** — **6 XP levels** each
- Right-click to open → **exactly 1 prize** per chest
- **Slot-machine style roll** (title/actionbar spin, then result GUI)
- Loot pool includes:
  - Cooked steak ×2 (very common)
  - All seed types ×2 (common): wheat, pumpkin, melon, beetroot, torchflower, pitcher pod
  - Golden apple, arrows ×8
  - White / Black scrolls (common)
  - Mystery Dust +1%
  - Rare: Potent Dust **+5%**, Radiant Dust **+10%**
  - Tier books Simple → Mastery (higher tiers rarer)

### Commands / shop
- `/ce:shop prize` — buy 1 prize chest
- Shop UI: Prize Chest + quick buy

---

## Changed

### XP shop books
- **Per-tier buying restored** (Simple → Mastery with original level costs)
- Random enchant **within the chosen tier**
- Each book **rolls its own success % and destroy %** (stored on the book)
- Dust still adds +1% success (cap +50%); +5% / +10% dust from prizes only

### Combat (CosmicPvP-style, project rules preserved)
- **Rage** — combo hits: **+0.5 hearts per stack**, max **5** stacks (Pacify can block)
- **Bleed / Twinge / Deep Bleed** — stacks slow movement + **continuous tick damage**
- **Devour** — **multiplies** damage vs targets with active bleed stacks
- **Cleave / Mighty Cleave** — splash damage; radius scales with level
- Sword / axe / bow / tool effects tuned closer to Cosmic numbers (Assassin, Greatsword, Insanity, Sniper, Longbow, Detonate, etc.)

### Lightning
- Player-summoned thunder **does not burn flammables** (fire cleared around strike)
- Caster is **immune** to their own bolt / residual fire

### Descriptions
- Removed trailing `(Cosmic)` text from enchant descriptions

---

## Fixed / carried forward (still in this build)

These were already in or before `v1.4.13` and remain intentional:

| Feature | Behavior |
|--------|----------|
| White Scroll | All armor, weapons, tools (any material) |
| Black Scroll | Gear never breaks; extract → real books; **100% destroy** on apply fail |
| Blessed | Cleanses **once per debuff episode** only |
| Drunk / Glowing | No flicker / toggle bugs |
| Max enchants | **9** per piece; full pieces hidden from new-book apply |
| Apply flow | Right-click GUI (Bedrock has no drag-drop apply) |
| Autosmelt | Expanded ore / raw list |

---

## Install

1. Download **`CosmicEnchantsBE_v1.4.19.mcaddon`**
2. Double-click to import (or open with Minecraft)
3. World settings → enable **Behavior Pack** + **Resource Pack**
4. Enable **Beta APIs** / experiments if prompted
5. Fully leave and rejoin (Realms: rejoin after update)
6. Confirm chat: **`v1.4.19 Ready`**

### Admin free shop
```
/tag @s add ce_admin
```

---

## Shop prices (quick)

| Item | Cost |
|------|------|
| Simple → Mastery books | 2 / 5 / 7 / 10 / 14 / 18 / 23 / 30 levels |
| Prize Chest | **6** levels |
| White Scroll | 5 levels |
| Black Scroll | 10 levels |
| Mystery Dust (+1%) | 5 levels |

---

## Version timeline (1.4.13 → 1.4.19)

| Version | Highlights |
|---------|------------|
| 1.4.13 | Maxed gear hidden from apply |
| 1.4.14 | Rolled book rates; safe lightning |
| 1.4.15 | Prize chest + dust tiers + seeds/steak later |
| 1.4.16 | Tier book shop restored |
| 1.4.17 | Slot-machine prize UI |
| 1.4.18 | Rage/Bleed/Devour/Cleave Cosmic combat pass |
| **1.4.19** | Clean release; description polish; this patch doc |
